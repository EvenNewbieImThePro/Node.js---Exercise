var names = "이유덕,이재영,권종표,이재영,박민호,강상희,이재영,김지완,최승혁,이성연,박영서,박민호,전경헌,송정환,김재성,이유덕,전경헌".split(',')
console.log(names.length);

var countlee=0;
var countkim=0;

for(var i=0; i < names.length; i++)
{
    var fullname = names[i];
    if (names[0] === "이")
        countlee++;
    else if (fullname[0]==="김")
        countkim++;
}

console.log("이씨는 " +countlee+ "명");
console.log("김씨는 " +countkim+ "명");

var jaecount = 0;
for(var i=0; i < names.length; i++)
{
    var jaeyoung = names[i];
    if ( jaeyoung[0]=== "이" & jaeyoung[1]=== "재" & jaeyoung[2]=== "영")
        jaecount++;
}
console.log("이재영씨 " +jaecount+ "번 중복.");

var firstname=names[i]
for(var i=0; i < names.length; i++)
{
        
    
}


